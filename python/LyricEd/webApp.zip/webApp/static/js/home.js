$(document).ready(function () {
    /*var jumboHeight = $('.jumbotron').outerHeight() + $('nav').outerHeight();
    parallax();

    function parallax() {
        var scrolled = $(window).scrollTop();
        $('.bg').css('height', (jumboHeight - scrolled) + 'px');
    }

    $(window).scroll(function () {
        parallax();
    });*/
});